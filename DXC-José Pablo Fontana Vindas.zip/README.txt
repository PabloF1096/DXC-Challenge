﻿practitioner: José Pablo Fontana Vindas

This is an example of the use of web services

For the Database I used MySQL database running on a WAMPP server

All you have to do is run the "dxc.sql" script in the Database to generate the schema

After that, all you have to do is deploy the "REST_Application.war" file located in the dist folder of the project

I used the Payara server (specifically Payara5) to deploy the .war file(Be aware that to run the .war file, the database has to be accessed)

Finally, for tests I used the Postman application


